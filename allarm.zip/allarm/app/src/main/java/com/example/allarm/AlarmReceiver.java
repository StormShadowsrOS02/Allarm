package com.example.allarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.media.MediaPlayer;

public class AlarmReceiver extends BroadcastReceiver {
    private static MediaPlayer mediaPlayer;

    @Override
    public void onReceive(Context context, Intent intent) {
        // Активируем экран устройства
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "AlarmApp:WakeLock");
        wakeLock.acquire(3000);

        // Запускаем PuzzleActivity
        Intent puzzleIntent = new Intent(context, PuzzleActivity.class);
        puzzleIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(puzzleIntent);

        // Воспроизводим аудиофайл
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(context, R.raw.sound);
            mediaPlayer.setLooping(true); // Зацикливаем звук
        }
        mediaPlayer.start();

        // Освобождаем WakeLock
        wakeLock.release();
    }

    // Метод для остановки звука, который можно вызывать из PuzzleActivity
    public static void stopAlarmSound() {
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.stop();
            }
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}