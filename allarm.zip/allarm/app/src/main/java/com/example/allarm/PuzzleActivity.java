package com.example.allarm;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class PuzzleActivity extends AppCompatActivity {
    private LinearLayout puzzleContainer;
    private Button submitButton;
    private List<EditText> answerFields = new ArrayList<>();
    private List<Integer> correctAnswers = new ArrayList<>();
    private int numberOfPuzzles = 5; // Устанавливаем количество примеров

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puzzle);

        puzzleContainer = findViewById(R.id.puzzleContainer);
        submitButton = findViewById(R.id.submitButton);

        // Генерация нескольких примеров
        generatePuzzles(numberOfPuzzles);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAnswers();
            }
        });
    }

    private void generatePuzzles(int count) {
        Random random = new Random();
        for (int i = 0; i < count; i++) {
            int operation = random.nextInt(4); // 0 - сложение, 1 - вычитание, 2 - умножение, 3 - деление
            int num1 = random.nextInt(10) + 1;
            int num2 = random.nextInt(10) + 1;
            int answer = 0;
            String question = "";

            switch (operation) {
                case 0:
                    answer = num1 + num2;
                    question = num1 + " + " + num2 + " = ?";
                    break;
                case 1:
                    answer = num1 - num2;
                    question = num1 + " - " + num2 + " = ?";
                    break;
                case 2:
                    answer = num1 * num2;
                    question = num1 + " * " + num2 + " = ?";
                    break;
                case 3:
                    answer = num1; // Установим answer как num1 для деления без остатка
                    question = (num1 * num2) + " / " + num2 + " = ?";
                    break;
            }

            correctAnswers.add(answer);

            // Создаём TextView для вопроса
            TextView questionView = new TextView(this);
            questionView.setText(question);
            puzzleContainer.addView(questionView);

            // Создаём EditText для ответа
            EditText answerField = new EditText(this);
            answerField.setHint("Answer");
            answerFields.add(answerField);
            puzzleContainer.addView(answerField);
        }
    }

    private void checkAnswers() {
        boolean allCorrect = true;

        for (int i = 0; i < numberOfPuzzles; i++) {
            try {
                int userAnswer = Integer.parseInt(answerFields.get(i).getText().toString());
                if (userAnswer != correctAnswers.get(i)) {
                    allCorrect = false;
                    break;
                }
            } catch (NumberFormatException e) {
                allCorrect = false;
                break;
            }
        }

        if (allCorrect) {
            Toast.makeText(PuzzleActivity.this, "All answers correct! Alarm off", Toast.LENGTH_SHORT).show();
            AlarmReceiver.stopAlarmSound();
            finish();
        } else {
            Toast.makeText(PuzzleActivity.this, "Incorrect answers! Try again.", Toast.LENGTH_SHORT).show();
        }
    }
}